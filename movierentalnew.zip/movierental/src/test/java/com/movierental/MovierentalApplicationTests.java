package com.movierental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovierentalApplicationTests {

	@Test
	void contextLoads() {
	}

}
