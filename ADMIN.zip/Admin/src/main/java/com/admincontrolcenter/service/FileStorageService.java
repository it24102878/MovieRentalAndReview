package com.admincontrolcenter.service;

import com.admincontrolcenter.model.Admin;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

@Service
public class FileStorageService {

    private static final String ADMINS_FILE = "src/main/resources/data/admins.txt";
    private static final String ACTIVITY_LOG = "src/main/resources/data/activity.log";

    public void saveAdmin(Admin admin) throws IOException {
        // Ensure the data directory and file exist
        Files.createDirectories(Paths.get("src/main/resources/data"));
        if (!Files.exists(Paths.get(ADMINS_FILE))) {
            Files.createFile(Paths.get(ADMINS_FILE));
        }

        // Append admin details to admins.txt
        Files.writeString(
                Paths.get(ADMINS_FILE),
                admin.toFileString() + System.lineSeparator(),
                StandardOpenOption.CREATE, StandardOpenOption.APPEND
        );
        logActivity("Admin created: " + admin.getEmail());
    }

    public List<Admin> getAllAdmins() throws IOException {
        List<Admin> admins = new ArrayList<>();
        if (!Files.exists(Paths.get(ADMINS_FILE))) {
            return admins; // Return empty list if file doesn't exist
        }
        List<String> lines = Files.readAllLines(Paths.get(ADMINS_FILE));
        for (String line : lines) {
            if (!line.trim().isEmpty()) {
                admins.add(Admin.fromFileString(line));
            }
        }
        return admins;
    }

    public void updateAdmin(Admin updatedAdmin) throws IOException {
        List<Admin> admins = getAllAdmins();
        List<String> updatedLines = new ArrayList<>();
        for (Admin admin : admins) {
            if (admin.getId().equals(updatedAdmin.getId())) {
                updatedLines.add(updatedAdmin.toFileString());
            } else {
                updatedLines.add(admin.toFileString());
            }
        }
        Files.write(Paths.get(ADMINS_FILE), String.join(System.lineSeparator(), updatedLines).getBytes());
        logActivity("Admin updated: " + updatedAdmin.getEmail());
    }

    public void deleteAdmin(String id) throws IOException {
        List<Admin> admins = getAllAdmins();
        Admin deletedAdmin = null;
        for (Admin admin : admins) {
            if (admin.getId().equals(id)) {
                deletedAdmin = admin;
                break;
            }
        }
        admins.removeIf(admin -> admin.getId().equals(id));
        List<String> updatedLines = new ArrayList<>();
        for (Admin admin : admins) {
            updatedLines.add(admin.toFileString());
        }
        Files.write(Paths.get(ADMINS_FILE), String.join(System.lineSeparator(), updatedLines).getBytes());
        if (deletedAdmin != null) {
            logActivity("Admin deleted: " + deletedAdmin.getEmail());
        }
    }

    public void logActivity(String activity) throws IOException {
        String logEntry = java.time.LocalDateTime.now() + ": " + activity + System.lineSeparator();
        Files.writeString(
                Paths.get(ACTIVITY_LOG),
                logEntry,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND
        );
    }

    public List<String> getActivityLogs() throws IOException {
        if (!Files.exists(Paths.get(ACTIVITY_LOG))) {
            return new ArrayList<>(); // Return empty list if file doesn't exist
        }
        return Files.readAllLines(Paths.get(ACTIVITY_LOG));
    }
}