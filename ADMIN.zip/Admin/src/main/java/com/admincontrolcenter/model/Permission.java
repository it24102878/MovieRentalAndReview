package com.admincontrolcenter.model;

public enum Permission {
    FULL_ACCESS,
    LIMITED_ACCESS
}