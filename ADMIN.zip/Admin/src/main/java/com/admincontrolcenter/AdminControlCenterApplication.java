package com.admincontrolcenter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminControlCenterApplication {
	public static void main(String[] args) {
		SpringApplication.run(AdminControlCenterApplication.class, args);
	}
}