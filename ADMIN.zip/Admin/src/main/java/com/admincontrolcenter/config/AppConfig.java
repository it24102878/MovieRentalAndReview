package com.admincontrolcenter.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    // Add any specific configurations if needed
}