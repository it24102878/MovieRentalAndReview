package com.moviesphere;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieSphereApplication {
	public static void main(String[] args) {
		SpringApplication.run(MovieSphereApplication.class, args);
	}
}